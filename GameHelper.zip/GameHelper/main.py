import tkinter as tk
from tkinter import messagebox, filedialog, ttk
import os
import json
import time
import subprocess

SAVE_FILE = "games.json"

# ========== JSON İŞLEMLERİ ==========
def save_data(data):
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def load_data():
    if not os.path.exists(SAVE_FILE) or os.path.getsize(SAVE_FILE) == 0:
        default_data = {"games": {}, "playtime": {}}
        save_data(default_data)
        return default_data
    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            default_data = {"games": {}, "playtime": {}}
            save_data(default_data)
            return default_data

data = load_data()
games = data["games"]
playtime = data["playtime"]

current_game = None
start_time = None

# ========== OYUN EKLEME ==========
def add_game():
    exe_path = filedialog.askopenfilename(title="Oyun exe dosyasını seç", filetypes=[("EXE Files", "*.exe")])
    if not exe_path:
        return
    name = os.path.basename(exe_path)
    games[name] = exe_path
    if name not in playtime:
        playtime[name] = 0
    save_data({"games": games, "playtime": playtime})
    refresh_list()
    messagebox.showinfo("Başarılı", f"{name} eklendi!")

def refresh_list():
    game_listbox.delete(0, tk.END)
    for g in games:
        game_listbox.insert(tk.END, g)

# ========== OYUN BAŞLAT ==========
def launch_game():
    global current_game, start_time
    selection = game_listbox.curselection()
    if not selection:
        messagebox.showwarning("Hata", "Bir oyun seçmelisin!")
        return
    game_name = game_listbox.get(selection[0])
    exe_path = games[game_name]
    if not os.path.exists(exe_path):
        messagebox.showerror("Hata", f"Oyun bulunamadı:\n{exe_path}")
        return
    subprocess.Popen(exe_path, shell=True)
    current_game = game_name
    start_time = time.time()
    messagebox.showinfo("Bilgi", f"{game_name} başlatıldı!")

# ========== OYUN DURDUR ==========
def stop_game():
    global current_game, start_time
    if not current_game or not start_time:
        messagebox.showwarning("Hata", "Hiç oyun başlatılmadı!")
        return
    elapsed = int(time.time() - start_time)
    playtime[current_game] += elapsed
    save_data({"games": games, "playtime": playtime})
    saat = playtime[current_game] // 3600
    dakika = (playtime[current_game] % 3600) // 60
    messagebox.showinfo("Oyun Süresi", f"{current_game} toplam süre: {saat} saat {dakika} dk")
    current_game = None
    start_time = None

# ========== OPTİMİZE ==========
def optimize_game():
    selection = game_listbox.curselection()
    if not selection:
        messagebox.showwarning("Hata", "Bir oyun seçmelisin!")
        return
    game_name = game_listbox.get(selection[0])
    exe_path = games[game_name]
    folder = os.path.dirname(exe_path)
    
    # Kullanıcının seçtiği değerler
    fps = fps_combo.get()
    res = res_combo.get()
    shadow = shadow_combo.get()
    texture = texture_combo.get()
    aa = aa_combo.get()
    
    # system.ini oluştur / güncelle
    ini_path = os.path.join(folder, "system.ini")
    with open(ini_path, "w") as f:
        f.write(f"[Graphics]\nFPS={fps}\nResolution={res}\nShadow={shadow}\nTexture={texture}\nAntiAliasing={aa}\n")
    
    # optimize.dat oluştur
    optimize_path = os.path.join(folder, "optimize.dat")
    with open(optimize_path, "w") as f:
        f.write(f"FPS={fps}\nResolution={res}\nShadow={shadow}\nTexture={texture}\nAntiAliasing={aa}\n")
    
    messagebox.showinfo("Optimize Edildi", f"{game_name} için optimize dosyaları oluşturuldu!\n(system.ini ve optimize.dat)")

# ========== OYUN SÜRELERİNİ GÖSTER ==========
def show_playtime():
    if not playtime:
        messagebox.showinfo("Bilgi", "Henüz oynanan oyun yok.")
        return
    metin = "Oyun Süreleri:\n\n"
    for oyun, sure in playtime.items():
        saat = sure // 3600
        dakika = (sure % 3600) // 60
        metin += f"{oyun}: {saat} saat {dakika} dk\n"
    messagebox.showinfo("Oyun Süreleri", metin)

# ========== ARAYÜZ ==========
root = tk.Tk()
root.title("GameHelper - Yerli & Milli 🎮")
root.geometry("800x550")

# Sol panel
frame_left = tk.Frame(root)
frame_left.pack(side="left", fill="y", padx=10, pady=10)

game_listbox = tk.Listbox(frame_left, height=25, width=35)
game_listbox.pack()
refresh_list()

add_button = tk.Button(frame_left, text="Oyun Ekle (Dosyadan)", command=add_game)
add_button.pack(pady=2)

launch_button = tk.Button(frame_left, text="Oyunu Başlat", command=launch_game)
launch_button.pack(pady=2)

stop_button = tk.Button(frame_left, text="Oyun Bitir", command=stop_game)
stop_button.pack(pady=2)

show_time_button = tk.Button(frame_left, text="Oyun Sürelerini Göster", command=show_playtime)
show_time_button.pack(pady=2)

optimize_button = tk.Button(frame_left, text="Optimize Et", command=optimize_game)
optimize_button.pack(pady=2)

# Sağ panel - ayarlar
frame_right = tk.Frame(root)
frame_right.pack(side="right", fill="both", expand=True, padx=10, pady=10)

# FPS
tk.Label(frame_right, text="FPS:").pack()
fps_options = ["60", "75", "120", "144", "240"]
fps_combo = ttk.Combobox(frame_right, values=fps_options, state="readonly")
fps_combo.current(2)
fps_combo.pack()

# Çözünürlük
tk.Label(frame_right, text="Çözünürlük:").pack()
res_options = ["1280x720", "1920x1080", "2560x1440", "3840x2160"]
res_combo = ttk.Combobox(frame_right, values=res_options, state="readonly")
res_combo.current(1)
res_combo.pack()

# Gölge
tk.Label(frame_right, text="Gölge:").pack()
shadow_options = ["Düşük", "Orta", "Yüksek", "Ultra"]
shadow_combo = ttk.Combobox(frame_right, values=shadow_options, state="readonly")
shadow_combo.current(2)
shadow_combo.pack()

# Texture
tk.Label(frame_right, text="Texture Kalitesi:").pack()
texture_options = ["Düşük", "Orta", "Yüksek", "Ultra"]
texture_combo = ttk.Combobox(frame_right, values=texture_options, state="readonly")
texture_combo.current(2)
texture_combo.pack()

# Anti-Aliasing
tk.Label(frame_right, text="Anti-Aliasing:").pack()
aa_options = ["FXAA", "TAA", "MSAA", "Off"]
aa_combo = ttk.Combobox(frame_right, values=aa_options, state="readonly")
aa_combo.current(0)
aa_combo.pack()

# Teşekkür Notu
tesekkur = """\
GameHelper - GameGameStudios x ChatGPT 🇹🇷

Bu yazılım GameGameStudios tarafından geliştirilmiştir.
Tüm grafik ayarlarını buton ve seçimlerle yapabilirsiniz.
Oyun sürelerini takip edin, performansı optimize edin.

Teşekkürler: ChatGPT & Muhsin
"""
tk.Label(frame_right, text=tesekkur, justify="left", font=("Arial", 9)).pack(pady=10)

root.mainloop()


